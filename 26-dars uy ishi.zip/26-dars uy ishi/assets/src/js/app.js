jQuery(document).ready(function($){

	$('.carousel').carousel();
	$('.unique-design').addClass('new-class'); 

});
